# theswitch
Jquery plugin checkbox simple switch control
